improvement from part 2

From the feedback i got from my leacture i was suposed to link my external CSS file with my HTML pages using this <link rel=" stlesheet" type = "CSS" href = "style.css">

For the final POE I am requiredd to creat a website using HTML, stylenthe web pages using external css then ADD html from so that i can be able to do form validation using javascript.

i also included the map on how custormes can visit us

i am also planning to add date and time update on all the pages



https://www.w3schools.com/html/default.asp#gsc.tab=0
